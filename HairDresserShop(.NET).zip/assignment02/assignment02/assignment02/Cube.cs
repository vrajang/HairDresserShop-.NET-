﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment02
{
    class Cube : Shape
    {
        double lengthofcube;

        public Cube(double loc)
        {
            lengthofcube = loc;
            

        }
        public override double CalculateArea()
        {
            Console.WriteLine("CUBE: Area "+ 6 * lengthofcube);
            return 6 * lengthofcube;
        }

        public override double CalculateVolume()
        {
            Console.WriteLine("CUBE :Volume "+ lengthofcube * lengthofcube * lengthofcube);
            return lengthofcube * lengthofcube * lengthofcube;

        }

        public override void SetData()
        {
            throw new NotImplementedException();
        }
    }
}

