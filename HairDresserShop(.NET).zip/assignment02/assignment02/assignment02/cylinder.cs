﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment02
{
    class cylinder : Shape
    {
        double radius;
        double height;
        public cylinder(double radiusofcylinder, double heightofcylinder)
        {

            radius = radiusofcylinder;
            height = heightofcylinder;

        }

        

            



            
        public override double CalculateArea()
        {
            double x = 2 * PI * radius * height + 2 * PI * radius * radius;
            Console.WriteLine("CYLINDER :Area "+ x);
            return 2 * PI * radius * height + 2 * PI * radius * radius;
        }

        public override double CalculateVolume()
        {
            Console.WriteLine("CYLINDER :volume "+ PI * radius * radius * height);
            return PI * radius * radius * height;
        }

        public override void SetData()
        {
            throw new NotImplementedException();
        }
    }
}
