﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment02
{
    class box : Shape
    {
        double lengthofbox;
        double breathofbox;
        double heightofbox;
        public box(double lob,double bob,double hob)
        {
            lengthofbox = lob;
            breathofbox = bob;
            heightofbox = hob;

        }

        public override double CalculateArea()
        {
            double x=  2 * (lengthofbox * breathofbox) + 2 * (breathofbox * heightofbox) + 2 * (lengthofbox * heightofbox);
            Console.WriteLine("BOX: Area " + x);
            return x;
            
        }

        public override double CalculateVolume()
        {
            Console.WriteLine("BOX: Area " + lengthofbox * breathofbox * heightofbox);

            return lengthofbox * breathofbox * heightofbox;
        }

        public override void SetData()
        {
            throw new NotImplementedException();
        }
        
    }
}
