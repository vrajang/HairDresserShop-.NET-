﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment02
{
    class circle:Shape
    {
        double radius = 0;

        public circle(double r)
        {

            radius = r;
        
        }
            
        public override double CalculateArea()
        {
            Console.WriteLine("CIRCLE :Area "+ PI * radius * radius);
            return PI * radius * radius;
        }

        public override double CalculateVolume()
        {
            throw new NotImplementedException();
        }

        public override void SetData()
        {
            throw new NotImplementedException();
        }
    }
}
