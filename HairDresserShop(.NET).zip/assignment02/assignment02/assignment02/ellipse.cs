﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment02
{
    class ellipse : Shape
    {
        double a = 0;
        double b = 0;

        public ellipse(double value1 , double value2)
        {
            a = value1;
            b = value2;
        }
        public override double CalculateArea()
        {
            Console.WriteLine("Elipse :Area "+ PI * a * b);
            return PI * a * b;
        }

        public override double CalculateVolume()
        {
            throw new NotImplementedException();
        }

        public override void SetData()
        {
            throw new NotImplementedException();
        }
    }
}
