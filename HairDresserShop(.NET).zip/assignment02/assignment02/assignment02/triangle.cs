﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment02
{
    class triangle:Shape
    {
        // private data member 
        double height = 0;
        double breath = 0;
        double x = 0;


        // method of  square class 
        public triangle(double h, double b)
        {
            height = h;
            breath = b;
        }

        public override double CalculateArea()
        {

            x = (height * breath)/2;
            Console.WriteLine("TRIANGLE :Area " + x);

            
            return x;
        }



        public override double CalculateVolume()
        {
            throw new NotImplementedException();
        }


        public override void SetData()
        {
            throw new NotImplementedException();
        }
        public string ToString()
        {
            Console.WriteLine("RECTANGLE :Area " + x);
            return base.ToString();
        }
    }
}
