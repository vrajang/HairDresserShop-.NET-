﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment02
{
    class sphere:Shape
    {
        double radius = 0;

        public sphere(double r)
        {

            radius = r;

        }

        public override double CalculateArea()
        {
            Console.WriteLine("SPHERE :Area " + 4* PI * radius * radius);
            return 4*PI * radius * radius;
        }

        public override double CalculateVolume()
        {
            Console.WriteLine("SPHERE :Volume " + (4 * PI * radius * radius*radius)/3);
            return (4 * PI * radius * radius * radius) / 3;
        }

        public override void SetData()
        {
            throw new NotImplementedException();
        }
    }
}
