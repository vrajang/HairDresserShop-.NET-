﻿///I, vrajang shah, certify that this material is my original work. No other person's work has been used without due acknowledgement.
///
///Author:vrajang shah
///Date: october 2020

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment02
{
    class Class1
        ///in this assignment we are providing menu for creating instance of object to obtain their volumes and areas
        ///by taking the user input and calculating the volumes and area through require methos by calling specific classes
        ///belong to that category
    {
        const string DATAFILE = "SHAPES.txt";
        public static void Main()
        {
            bool running = true;  // same as boolean in java
            ///this while loop is to create for continous selection 
            ///Switch case is use to make selection and get the output on based of made selection
            ///case1 to case 10 are choices for shape you have to select any number for shape 
            

            while (running)
            {
                Console.Clear();                  // Clear the Console  

                Console.WriteLine("MENU FOR THE SHAPES ");
                Console.WriteLine("\n1>Rectangle");
                Console.WriteLine("2>Square");
                Console.WriteLine("3>box");
                Console.WriteLine("4>cube");
                Console.WriteLine("5>Ellipse");
                Console.WriteLine("6>circle");
                Console.WriteLine("7>cylinder");
                Console.WriteLine("8>Triangle");
                Console.WriteLine("9>Sphere");
                Console.WriteLine("10>Tetrahedron");                
                Console.WriteLine("\n11>Exit");
                Console.WriteLine("\nEnter any ony one choice from 1 to 10:");
                String option = Console.ReadLine();
                /// <summary>
                /// this part works after making a choice
                ///taking the user input in every cases for calculating length and volume 
                switch (option.ToUpper())
                {
                    ///case 1 :::rectangle 
                    case "1":
                        Console.WriteLine("Enter length");
                        var L =double.Parse(Console.ReadLine());
                        Console.WriteLine("Enter breath");
                        var R = double.Parse(Console.ReadLine());

                       ///r1 >> object created for rectangle
                        Shape r1 = new Rectangle(L, R);
                        r1.CalculateArea();




                        break;

                    case "2":

                        Console.WriteLine("Enter length");
                        var Los = double.Parse(Console.ReadLine());
                        ///s1>> object for shape
                        Shape s1 = new Square(Los);
                        s1.CalculateArea();

                        

                        break;

                    case "3":
                        
                        Console.WriteLine("Enter length of box");
                        var Lob = double.Parse(Console.ReadLine());
                        Console.WriteLine("Enter breath of box");
                        var Bob = double.Parse(Console.ReadLine());
                        Console.WriteLine("Enter height of box");
                        var Hob = double.Parse(Console.ReadLine());

                        Shape b1 = new box(Lob,Bob,Hob);
                        b1.CalculateArea();
                        b1.CalculateVolume();



                        break;
                      case "4":
                        Console.WriteLine("Enter length of cube");
                        var Locube = double.Parse(Console.ReadLine());

                        Shape c1 = new Cube(Locube);
                        c1.CalculateArea();
                        c1.CalculateVolume();


                        break;

                    case "5":
                        Console.WriteLine("Enter value of A axis");
                        var axis  = double.Parse(Console.ReadLine());
                        Console.WriteLine("Enter value of B axis");
                        var bxis = double.Parse(Console.ReadLine());

                        Shape e1 = new ellipse(axis,bxis);
                        e1.CalculateArea();


                        break;
                    case "6":
                        Console.WriteLine("Enter radius of the circle");
                        var radC = double.Parse(Console.ReadLine());

                        Shape cir1 = new circle(radC);
                        cir1.CalculateArea();

                        break;
                    case "7":
                        Console.WriteLine("Enter radius of the cylinder");
                        var radcyl = double.Parse(Console.ReadLine());
                        Console.WriteLine("Enter height of the cylinder");
                        var hegcyl = double.Parse(Console.ReadLine());
                        Shape cyl1 = new cylinder(radcyl,hegcyl);
                        cyl1.CalculateArea();
                        cyl1.CalculateVolume();
                        break;

                    case "8":
                        Console.WriteLine("Enter Height of triangle");
                        var hot = double.Parse(Console.ReadLine());
                        Console.WriteLine("Enter Breath of triangle");
                        var bot = double.Parse(Console.ReadLine());

                        Shape t1 = new triangle(hot,bot);
                        t1.CalculateArea();

                        break;

                    case "9":
                        Console.WriteLine("Enter radius of sphere");
                        var ros = double.Parse(Console.ReadLine());
                        Shape S1 = new sphere(ros);
                        S1.CalculateArea();
                        S1.CalculateVolume();

                        break;
                    case "10":
                        Console.WriteLine("Enter Height of trtrahedron");
                        var hotet = double.Parse(Console.ReadLine());
                        Console.WriteLine("Enter Breath of tetrahedron");
                        var botet = double.Parse(Console.ReadLine());

                        Shape tet1 = new tetrahedron(hotet, botet);
                        tet1.CalculateArea();

                        break;
                    case "11":
                        running = false;
                        break;
                    default:
                        Console.Error.WriteLine("Invalid option entered");
                        Console.Beep(); // Emit some sound 
                        break;
                }
                Console.Write("\nHit a key to continue ... ");
                Console.ReadKey();   // Will wait for any key to be pressed 
            }
            Console.WriteLine("\nBye...");


        }
        
    }
}
