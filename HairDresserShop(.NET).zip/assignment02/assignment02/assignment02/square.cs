﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment02
{// square class inherting 
 // the Shape class 
    internal class Square : Shape
    {

        // private data member 
        double side=0;

        // method of  square class 
        public Square(double n)
        {
            side = n;
        }

        public override double CalculateArea()
        {
            //Console.Write("Area of Square: ");
           // return side * side;
            Console.WriteLine("SQUARE :Area "+ side*side);
            return side;
        }

       

        public override double CalculateVolume()
        {
            throw new NotImplementedException();
        }

       
        public override void SetData()
        {
            throw new NotImplementedException();
        }
    }
}
