﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment02
{
    class Rectangle:Shape
    {

        // private data member 
        double length = 0;
        double breath = 0;
        double x = 0;


        // method of  square class 
        public Rectangle(double l, double b)
        {
            length = l;
            breath = b;
        }

        public override double CalculateArea()
        {

             x = length * breath;
            Console.WriteLine("RECTANGLE :Area " + x);

            //Console.Write("Area of Square: ");
            return x;
        }



        public override double CalculateVolume()
        {
            throw new NotImplementedException();
        }


        public override void SetData()
        {
            throw new NotImplementedException();
        }
        public  string ToString()
        {
            Console.WriteLine("RECTANGLE :Area " + x);
            return base.ToString();
        }
    }
}
