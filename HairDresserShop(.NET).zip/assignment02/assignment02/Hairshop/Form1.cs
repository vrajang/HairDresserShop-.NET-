﻿///I, vrajang shah, certify that this material is my original work. No other person's work has been used without due acknowledgement.
///
///Author:vrajang shah
///Date: october 2020
using System;
using System.Windows.Forms;
/// <summary>
/// in this assignment i had created the menu for hair dresser shop which provides variety of options to choose hairdresser and 
/// also provides an applicable discount to the peoples according to the policys 
/// </summary>
namespace Hairshop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// button handler 
        /// first of all we have to enter the values and select the proper option that will give you proper price  
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {




            double personprice = 0;//this is the price of an hairdresser
            double price1 = 0, price2 = 0, price3 = 0, price4 = 0; // this all are the price of services provided by the shop
            double clienttype = 0;//this tell you in which categoury you belongs for discount perpose
            try
            {

                //condition for price for hair dresser 
                if (radioButton1.Checked)
                {
                    personprice = 30;

                }
                else if (radioButton2.Checked)
                {

                    personprice = 45;


                }
                else if (radioButton3.Checked)
                {
                    personprice = 40;

                }
                else if (radioButton4.Checked)
                {

                    personprice = 50;
                }
                else
                {
                    personprice = 55;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "PLEASE SELECT RADIO BUTTON", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //condition ends for hairdresser

            try
            {
                //condition for selecting thr service they wants 

                if (checkBox1.Checked)
                {
                    price1 = 30;
                }

                if (checkBox2.Checked)
                {
                    price2 = 40;
                }
                if (checkBox3.Checked)
                {

                    price3 = 50;

                }
                if (checkBox4.Checked)
                {
                    price4 = 200;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "PLEASE SELECT SERVICES BUTTON", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //condition ends 

            try
            {
                //selection of categoury fo discount for instance "student ,adult...."
                if (radioButton6.Checked)
                {
                    clienttype = 1;
                }
                else if (radioButton7.Checked)
                {

                    clienttype = 0.9;
                }
                else if (radioButton8.Checked)
                {

                    clienttype = 0.95;
                }
                else
                {
                    clienttype = 0.85;

                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "PLEASE SELECT TYPE OF PERSON", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //condition ends 






            // this condition is for additional discount depends on number of visitd
            double additionaldiscount = 0;
            int vist = int.Parse(textBox1.Text);
            try
            {
                if (vist >= 0 && vist <= 3)
                {
                    additionaldiscount = 0;

                }
                else if (vist >= 4 && vist <= 8)
                {

                    additionaldiscount = 0.05;
                }
                else if (vist >= 9 && vist <= 13)
                {
                    additionaldiscount = 0.1;
                }
                else if (vist > 13)
                {

                    additionaldiscount = 0.15;
                }
                else {

                    MessageBox.Show("please enter the positive value");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "PLEASE SELECT RADIO BUTTON", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //condition ends for additional discountss 
            double alldiscount = clienttype - additionaldiscount;
            double total = (personprice + price1 + price2 + price3 + price4) * (alldiscount);
            textBox2.Text = $"{total:C}";

            return;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //this button handler clears the whole form
            textBox1.Clear();
            textBox2.Clear();
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            checkBox4.Checked = false;
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            radioButton5.Checked = false;
            radioButton6.Checked = false;
            radioButton7.Checked = false;
            radioButton8.Checked = false;
            radioButton9.Checked = false;

        }
        //closes the on going running form
        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
